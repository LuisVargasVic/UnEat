package com.example.fernandalopezcardenas.uneatfinal.Detail;

/**
 * Created by gabotrugomez on 11/14/17.
 */

public class ListModelPlate {

    private String Plate = "";
    private String ImagePlate = "";
    private String PlateURL = "";

    public void setPlateName(String PlateName){
        this.Plate = Plate;
    }

    public String getPlate() {
        return Plate;
    }

    public void setPlate(String plate) {
        Plate = plate;
    }

    public String getImagePlate() {
        return ImagePlate;
    }

    public void setImagePlate(String imagePlate) {
        ImagePlate = imagePlate;
    }

    public String getPlateURL() {
        return PlateURL;
    }

    public void setPlateURL(String plateURL) {
        PlateURL = plateURL;
    }



}
