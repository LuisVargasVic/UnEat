package com.example.fernandalopezcardenas.uneatfinal.Detail;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Calendar;

import com.example.fernandalopezcardenas.uneatfinal.R;

public class TimePicker extends Activity {

    private TimePicker timePicker1;
    private TextView time;
    private Calendar calendar;
    private String format = "";

    public TimePicker(){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_picker);

       final android.widget.TimePicker timePicker1 = (android.widget.TimePicker) findViewById(R.id.timePicker1);
        time = (TextView) findViewById(R.id.textView1);
        calendar = Calendar.getInstance();

        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        showTime(hour, min);
    }

    public TimePicker(TimePicker timePicker1, TextView time, Calendar calendar, String format) {
        this.timePicker1 = timePicker1;
        this.time = time;
        this.calendar = calendar;
        this.format = format;
    }

    public void setTime(View view) {
        showTime(currentHour(), currentMinute());
    }

    private int currentMinute() {
        int min = timePicker1.getCurrentMinute();
        return min;
    }
    private int currentHour() {
        int hour = timePicker1.getCurrentHour();
        return hour;
    }
    public int getCurrentMinute() {
        return currentMinute();
    }
    public int getCurrentHour() {
        return currentHour();
    }

    public void showTime(int hour, int min) {
        if (hour == 0) {
            hour += 12;
            format = "AM";
        } else if (hour == 12) {
            format = "PM";
        } else if (hour > 12) {
            hour -= 12;
            format = "PM";
        } else {
            format = "AM";
        }

        time.setText(new StringBuilder().append(hour).append(" : ").append(min)
                .append(" ").append(format));
    }
}

